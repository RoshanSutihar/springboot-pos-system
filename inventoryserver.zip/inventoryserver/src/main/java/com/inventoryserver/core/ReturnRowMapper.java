package com.inventoryserver.core;

public class ReturnRowMapper {

	
	
}
