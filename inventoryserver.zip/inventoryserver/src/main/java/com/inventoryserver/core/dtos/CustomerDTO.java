package com.inventoryserver.core.dtos;

public class CustomerDTO {
	private String customerName;
	
	public CustomerDTO(){}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
}
