package com.inventoryserver.core.dtos;

public class SupplierDTO {
private String supplierName;

SupplierDTO(){}

public String getSupplierName() {
	return supplierName;
}

public void setSupplierName(String supplierName) {
	this.supplierName = supplierName;
}




}
