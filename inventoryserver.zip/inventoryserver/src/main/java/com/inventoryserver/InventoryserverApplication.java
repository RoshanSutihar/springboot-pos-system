package com.inventoryserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryserverApplication.class, args);
	}

}
