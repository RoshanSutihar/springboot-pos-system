package com.inventoryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
